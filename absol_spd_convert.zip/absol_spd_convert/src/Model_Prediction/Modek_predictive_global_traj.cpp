#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Float64.h>
#include <hmcl_msgs/LaneArray.h>
#include <hmcl_msgs/Waypoint.h>
#include <vector>
#include <cmath>
#include <numeric>
#include <iostream>
#include <algorithm>

class ModelPredictive 
public:
    ModelPredictive() {
        ros::NodeHandle nh;
        target_pose_sub = nh.subscribe("/target_pose", 1000, &ModelPredictive::targetPoseCallback, this);
        target_velocity_sub = nh.subscribe("/target_velocity", 1000, &ModelPredictive::targetVelocityCallback, this);
        target_angular_sub = nh.subscribe("/target_angular", 1000, &ModelPredictive::targetAngularCallback, this);
        global_traj_sub = nh.subscribe("/global_traj", 1000, &ModelPredictive::globalTrajCallback, this);
        overtaking_traj_pub = nh.advertise<hmcl_msgs::LaneArray>("/overtaking_traj", 1000);
    }

    void targetPoseCallback(const geometry_msgs::Pose::ConstPtr& msg) {
        target_x = msg->position.x;
        target_y = msg->position.y;
        target_z = msg->position.z;
        target_orientation = {msg->orientation.x, msg->orientation.y, msg->orientation.z, msg->orientation.w};

        if (prediction_policy == "heuristic") {
            heuristicModelPredictive();
            intuitiveArtificialPotentialField2();
        } else if (prediction_policy == "MPC") {
            mpcModelPredictive();
            intuitiveArtificialPotentialField2();
        }
    }

    void targetVelocityCallback(const geometry_msgs::Twist::ConstPtr& msg) {
        target_velocity_x = msg->linear.x;
        target_velocity_y = msg->linear.y;
        target_velocity = std::sqrt(target_velocity_x * target_velocity_x + target_velocity_y * target_velocity_y);
        target_yaw = std::atan2(target_velocity_y, target_velocity_x);
    }

    void targetAngularCallback(const std_msgs::Float64::ConstPtr& msg) {
        target_angular_z = msg->data;
    }

    void globalTrajCallback(const hmcl_msgs::LaneArray::ConstPtr& msg) {
        cx.clear();
        cy.clear();
        for (const auto& lane : msg->lanes) {
            for (const auto& waypoint : lane.waypoints) {
                cx.push_back(waypoint.pose.pose.position.x);
                cy.push_back(waypoint.pose.pose.position.y);
            }
        }
        lane_data = msg->lanes;
        computePathFromWP(cx, cy, 0.05);
    }

    void cartesianToFrenet(const std::vector<std::pair<double, double>>& centerline, const std::pair<double, double>& point, double& s, double& l) {
        std::vector<double> arclength(centerline.size());
        std::adjacent_difference(centerline.begin(), centerline.end(), arclength.begin(), [](auto& p1, auto& p2) {
            return std::hypot(p1.first - p2.first, p1.second - p2.second);
        });
        std::partial_sum(arclength.begin(), arclength.end(), arclength.begin());

        double min_dist = std::numeric_limits<double>::infinity();
        for (size_t i = 1; i < centerline.size(); ++i) {
            auto& p1 = centerline[i - 1];
            auto& p2 = centerline[i];

            std::pair<double, double> line_vec = {p2.first - p1.first, p2.second - p1.second};
            std::pair<double, double> point_vec = {point.first - p1.first, point.second - p1.second};

            double line_len = std::hypot(line_vec.first, line_vec.second);
            double proj_length = (point_vec.first * line_vec.first + point_vec.second * line_vec.second) / line_len;

            std::pair<double, double> proj_point = {p1.first + proj_length * line_vec.first / line_len,
                                                    p1.second + proj_length * line_vec.second / line_len};

            double dist = std::hypot(point.first - proj_point.first, point.second - proj_point.second);
            if (dist < min_dist) {
                min_dist = dist;
                s = arclength[i - 1] + proj_length;
                l = dist;
            }
        }
    }

    std::pair<double, double> frenetToCartesian(const std::vector<std::pair<double, double>>& centerline, double s, double l) {
        std::vector<double> arclength(centerline.size());
        std::adjacent_difference(centerline.begin(), centerline.end(), arclength.begin(), [](auto& p1, auto& p2) {
            return std::hypot(p1.first - p2.first, p1.second - p2.second);
        });
        std::partial_sum(arclength.begin(), arclength.end(), arclength.begin());

        size_t segment_index = std::distance(arclength.begin(), std::lower_bound(arclength.begin(), arclength.end(), s)) - 1;

        auto& p1 = centerline[segment_index];
        auto& p2 = centerline[segment_index + 1];

        std::pair<double, double> segment_vector = {p2.first - p1.first, p2.second - p1.second};
        double segment_length = arclength[segment_index + 1] - arclength[segment_index];
        std::pair<double, double> segment_unit_vector = {segment_vector.first / segment_length, segment_vector.second / segment_length};

        std::pair<double, double> base_point = {p1.first + segment_unit_vector.first * (s - arclength[segment_index]),
                                                p1.second + segment_unit_vector.second * (s - arclength[segment_index])};

        std::pair<double, double> normal_vector = {-segment_unit_vector.second, segment_unit_vector.first};

        std::pair<double, double> cartesian_point = {base_point.first + normal_vector.first * l,
                                                     base_point.second + normal_vector.second * l};

        return cartesian_point;
    }

    void heuristicModelPredictive() {
        double model_prediction_x = target_x;
        double target_velocity_x = target_velocity_x;
        double target_yaw = target_yaw;
        double model_prediction_y = target_y;
        double target_velocity_y = target_velocity_y;
        double target_angular_z = target_angular_z;
        
        model_prediction_x_vec.clear();
        model_prediction_y_vec.clear();
        
        for (int i = 0; i < model_predicted_num; ++i) {
            model_prediction_x_vec.push_back(model_prediction_x);
            model_prediction_x += target_velocity_x;
            target_yaw += target_angular_z;
            target_velocity_x = target_velocity * std::cos(target_yaw);
        }
        
        for (int j = 0; j < model_predicted_num; ++j) {
            model_prediction_y_vec.push_back(model_prediction_y);
            model_prediction_y += target_velocity_y;
            target_yaw += target_angular_z;
            target_velocity_y = target_velocity * std::sin(target_yaw);
        }

    // void mpcModelPredictive() {
    //     // Implementation of the MPC model predictive logic in C++
    // }

    void IntuitiveArtificalPotentialField2() {
        auto start_time = std::chrono::high_resolution_clock::now();
        gain = 0.5;
        sigma = 0.01;
        radius = std::round(std::sqrt(1.0 / sigma) + 1.0);
        std::cout << "Radius: " << std::fixed << std::setprecision(3) << radius << std::endl;

        std::vector<std::pair<double, double>> potential_field_point;
        range_point_x.clear();
        range_point_y.clear();
        repulsed_potential_field_point_x.clear();
        repulsed_potential_field_point_y.clear();

        for (size_t i = 0; i < cx.size(); ++i) {
            double dist = std::sqrt(std::pow(model_prediction_x[2] - cx[i], 2) + std::pow(model_prediction_y[2] - cy[i], 2));
            if (dist < radius) {
                potential_field_point.push_back({cx[i], cy[i]});
            }
            if (dist < 2 * radius && dist > radius) {
                range_point_x.push_back(cx[i]);
                range_point_y.push_back(cy[i]);
            }
        }

        std::cout << "Potential field points: " << potential_field_point.size() << std::endl;

        auto point = std::make_pair(model_prediction_x[model_predicted_num / 2], model_prediction_y[model_predicted_num / 2]);
        auto [center_s, center_d] = cartesian_to_frenet(potential_field_point, point);
        auto [s1, d1] = cartesian_to_frenet(potential_field_point, {model_prediction_x[2], model_prediction_y[2]});

        for (const auto& j : potential_field_point) {
            auto [s, d] = cartesian_to_frenet(potential_field_point, j);
            for (int i = 0; i < model_predicted_num; ++i) {
                if (d1 >= 0) {
                    d -= gain * std::sqrt(std::max(0.0, (1.0 - sigma * std::pow(s - center_s, 2))));
                } else {
                    d += gain * std::sqrt(std::max(0.0, (1.0 - sigma * std::pow(s - center_s, 2))));
                }
            }
            repulsed_s = s;
            repulsed_d = d;
            std::tie(repulsed_x, repulsed_y) = frenet_to_cartesian(potential_field_point, repulsed_s, repulsed_d);
            repulsed_potential_field_point_x.push_back(repulsed_x);
            repulsed_potential_field_point_y.push_back(repulsed_y);
        }
        BezierCurve();

        auto end_time = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> execution_time = end_time - start_time;
        std::cout << "Execution time: " << execution_time.count() << " seconds" << std::endl;
    }

    void BezierCurve() {
        // Implementation of the Bezier curve logic in C++
    }

private:
    ros::Subscriber target_pose_sub;
    ros::Subscriber target_velocity_sub;
    ros::Subscriber target_angular_sub;
    ros::Subscriber global_traj_sub;
    ros::Publisher overtaking_traj_pub;

    double target_x, target_y, target_z;
    double target_velocity_x, target_velocity_y, target_velocity, target_yaw, target_angular_z;
    std::vector<double> cx, cy;
    std::string prediction_policy = "heuristic";
    std::vector<hmcl_msgs::Lane> lane_data;
    std::vector<double> control = {0, 0};
    std::vector<std::vector<double>> state = {{0, 0, 0, 0}};
    std::vector<double> model_prediction_x, model_prediction_y;
    std::vector<double> repulsed_potential_field_point_x, repulsed_potential_field_point_y;
    std::vector<double> range_point_x, range_point_y;
    std::array<double, 4> target_orientation;
    double gain = 1.0;
    double radius = 10.0;
    double sigma = 0.01;
    int model_predicted_num = 5;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "model_predictive");
    ModelPredictive mp;
    ros::spin();
    return 0;
}